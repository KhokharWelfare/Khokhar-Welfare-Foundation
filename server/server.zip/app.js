const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const authRoutes = require('./routes/auth');
const donationRoutes = require('./routes/donation');
const adminRoutes = require('./routes/admin');
const transactionRoutes = require('./routes/transaction');

// Load environment variables;
dotenv.config();

// Initialize express app;
const app = express();

//Middleware;
app.use(cors()); // Enable cors for React Frontend;
app.use(express.json);  //Paerser JSON request Bodies;

// Connect to mongodb atlas;
mongoose.connect(process.env.MONGOOSE_URI,{
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
    .then(()=>console.log('MongDB connected successfully.'))
    .catch(err=> console.log('MongoDB connection error: ', err));

// Define APIs;
app.use('/api/auth', authRoutes); // Authentication routes (login, register);
app.use('/api/donation', donationRoutes); // Donation routes (add, view);
app.use('/api/transaction', transactionRoutes); // Transaction Routes (track fund usage);
app.use('/api/admin', adminRoutes); // AdminRoutes (manage Donations, users);

// Basic Route for Testing;
app.get('/', (req, res) => {
    res.send('Family Walfare Website Running.');
});

// Start the server;
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
