const express = require('express');
const Donation = require('../models/Donation');
const {authMiddleware, adminMiddleware} = require('../middleware/auth');
const multer = require('multer');
const cloudinary = require('cloudinary').v2;
const router = express.Router();

cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
});

const storage = multer.memoryStorage();
const upload = multer({storage});

router.post('/', authMiddleware, upload.single('imageString'), async (req, res) => {
    const {donorName, amount} = req.body;
    try{
        if(!donorName || !amount ) return res.status(400).json({message: 'Please provide all the required data'});
        let imageString = '';
        if(req.file){
            const result = await new Promise((resolve, reject) => {
                const stream = cloudinary.uploader.upload_stream({folder: 'donation_proofs'},
                    (error, result ) => {
                        if(error) reject (error);
                        else resolve(result);
                    }
                );
                stream.end(req.file.buffer);
            });
            imageString = result.secure_url;
        }else{
            return res.status(400).json({message: 'Image  is required'});
        }

        const donation = new Donation({
            donorName, amount, imageString
        });
        await donation.save();
        res.status(201).json({donation});
    }catch(err){
        res.status(500).json({message: 'Server Error'});
    }
});

module.exports = router;